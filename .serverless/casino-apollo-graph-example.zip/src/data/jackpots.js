const jackpots = [
    {
        "game": "NEJACKANDTHEBEANSTALK",
        "amount": 69298
    },
    {
        "game": "LEPABLOPICASSOSLOT",
        "amount": 33263
    },
    {
        "game": "NEFLOWERS",
        "amount": 20790
    },
    {
        "game": "NESTARBURST",
        "amount": 103948
    },
    {
        "game": "NEALIENS",
        "amount": 59399
    },
    {
        "game": "NETHEWISHMASTER",
        "amount": 34649
    },
    {
        "game": "XGMONEYSPINNER",
        "amount": 20790
    },
    {
        "game": "BSTHEEXTERMINATOR",
        "amount": 29699
    },
    {
        "game": "NYXSUPERMAN",
        "amount": 9670
    },
    {
        "game": "NYXTHEFLASH",
        "amount": 83158
    },
    {
        "game": "NYXWONDERWOMAN",
        "amount": 34649
    }
];

module.exports = jackpots;
